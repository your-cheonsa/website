<?php
$servername = "localhost"; // Change to your database server name
$username = "root"; // Change to your database username
$password = ""; // Change to your database password
$dbname = "jewelry"; // Change to your database name

$conn = new mysqli("$servername", $username, $password, $dbname);
?>